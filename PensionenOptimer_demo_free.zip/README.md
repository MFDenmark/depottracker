# PensionenOptimer — Gratis demo (web)

Dette er en **gratis, simpel, mobil-first web-demo** du kan vise investorer.

## Hvad den kan
- Alder → hero-resultat (mulig vs normal pensionsalder) i **tid**
- Live justering af **ekstra opsparing** (slider + manuel indtastning)
- “Tilpas forudsætninger” (dropdown):
  - Referenceudbetaling (default 20.000)
  - Afkast (6–9%, default 7%)
- Micro Gains (konkrete scenarier, aldersprioriteret)
- Momentum (positiv/neutral)
- Lead-flow med preview
- Admin-view der viser leads (gemt lokalt i browseren)

## Vigtigt
- Beregningen er en **forenklet DEMO-model** (konservativ, monotont, stabil).
- Ikke rådgivning.
- Leads sendes ikke til nogen; de gemmes i browserens `localStorage`.

## Sådan kører du den gratis
### Mulighed A (helt uden værktøj)
1. Dobbeltklik på `index.html`

### Mulighed B (GitHub Pages – gratis)
1. Opret et GitHub repo
2. Upload filer: `index.html`, `style.css`, `app.js`
3. Settings → Pages → Deploy from branch

### Mulighed C (Netlify – gratis)
1. Træk mappen ind på Netlify
2. Du får en URL på 30 sek.

## Næste iteration
Når demoen er godkendt, kan vi:
- Erstatte demo-beregningen med den endelige engine
- Tilføje SLA og rigtige partnerhooks (lead routing)
- Tilføje analytics (kun ikke-følsomme events)
