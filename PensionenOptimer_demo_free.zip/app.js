
/**
 * PensionenOptimer — DEMO
 * - Forenklet, konservativ model
 * - Ikke rådgivning
 * - Lead gemmes i localStorage
 */

const $ = (sel) => document.querySelector(sel);
const $$ = (sel) => Array.from(document.querySelectorAll(sel));

const state = {
  profile: { age: null },
  assumptions: {
    normal_pension_age: 67,     // demo default (lov-reference kan senere hentes dynamisk)
    return_rate: 0.07,          // default
    payout_target_monthly: 20000 // standard
  },
  scenario: {
    extra_saving_monthly: 0,
    micro_gain_id: null
  },
  momentum: {
    last_seen_at: null,
    last_possible_age: null
  }
};

// ---------- Helpers ----------
function clamp(n, a, b){ return Math.max(a, Math.min(b, n)); }

function fmtInt(n){
  return new Intl.NumberFormat('da-DK', { maximumFractionDigits: 0 }).format(n);
}

function fmtAge(age){
  // age might be fractional: show "X år Y mdr" conservatively
  const years = Math.floor(age);
  const months = Math.round((age - years) * 12);
  if(months === 0) return `${years} år`;
  return `${years} år ${months} mdr`;
}

function fmtDeltaYearsToText(deltaYears){
  // Convert years difference to adaptive units.
  const days = Math.round(deltaYears * 365);
  if(days < 45) return `${days} dage`;
  const months = Math.round(deltaYears * 12);
  if(days <= 540) return `${months} mdr`;
  const years = Math.floor(months / 12);
  const rem = months % 12;
  if(rem === 0) return `${years} år`;
  return `${years} år ${rem} mdr`;
}

function nowStamp(){
  const d = new Date();
  return d.toLocaleString('da-DK');
}

function screen(name){
  $$('[data-screen]').forEach(el => {
    el.classList.toggle('hidden', el.getAttribute('data-screen') !== name);
  });
}

function getLeads(){
  try { return JSON.parse(localStorage.getItem('po_leads') || '[]'); } catch { return []; }
}
function setLeads(leads){
  localStorage.setItem('po_leads', JSON.stringify(leads));
}

// ---------- Demo Calculation Model ----------
/**
 * Goal: stable, monotonic, conservative.
 *
 * We approximate "years bought back" from extra monthly saving with a diminishing return.
 * This is NOT a production-grade pension model; it is a demo that preserves expected UX behavior.
 *
 * Intuition:
 * - More extra saving => earlier retirement
 * - Higher payout target => later retirement (less years bought)
 * - Higher return => slightly earlier retirement
 * - Cannot retire before a minimum bound relative to normal pension age.
 */
function computeResult(){
  const age = state.profile.age;
  const normal = state.assumptions.normal_pension_age;
  const r = state.assumptions.return_rate;
  const payout = state.assumptions.payout_target_monthly;
  const extra = state.scenario.extra_saving_monthly;

  const yearsToNormal = Math.max(0, normal - age);

  // Conservative "effective annual extra" with mild return effect
  const extraAnnual = extra * 12;
  const returnFactor = 0.85 + (r - 0.06) * 2.5; // 6% -> ~0.85, 9% -> ~0.925
  const payoutFactor = 20000 / Math.max(12000, payout); // higher payout reduces effect

  // Diminishing returns: log scale prevents absurd results
  const raw = Math.log1p(extraAnnual / 10000) * 2.8; // ~0.. (slow growth)
  const yearsBought = raw * returnFactor * payoutFactor * Math.sqrt(Math.max(0.5, yearsToNormal / 20));

  // Minimum retirement age: can't be earlier than (normal - 15 years) in demo
  const minAge = Math.max(18, normal - 15);

  const possible = clamp(normal - yearsBought, minAge, normal);

  const deltaYears = normal - possible;

  return {
    possible_pension_age: possible,
    normal_pension_age: normal,
    delta_years: deltaYears,
    display_delta: fmtDeltaYearsToText(deltaYears)
  };
}

function renderHero(){
  const res = computeResult();
  $('#possibleAge').textContent = fmtAge(res.possible_pension_age);
  $('#normalAge').textContent = fmtAge(res.normal_pension_age);
  $('#deltaTime').textContent = res.display_delta;

  $('#valNormal').textContent = fmtAge(res.normal_pension_age);
  $('#valPossible').textContent = fmtAge(res.possible_pension_age);

  // Mini chart widths: map to relative within [minAge..normal]
  const minAge = Math.max(18, res.normal_pension_age - 15);
  const span = res.normal_pension_age - minAge;

  const wNormal = 100;
  const wPossible = span === 0 ? 100 : ((res.possible_pension_age - minAge) / span) * 100;

  $('#barNormal').style.width = `${wNormal}%`;
  $('#barPossible').style.width = `${clamp(wPossible, 0, 100)}%`;
}

function renderAdjustPreview(){
  const res = computeResult();
  $('#possibleAge2').textContent = fmtAge(res.possible_pension_age);
  $('#deltaTime2').textContent = res.display_delta;
}

function updateMomentum(){
  const res = computeResult();
  const last = state.momentum.last_seen_at;
  const now = new Date();

  $('#lastCheckin').textContent = last ? new Date(last).toLocaleString('da-DK') : '—';
  $('#nowCheckin').textContent = now.toLocaleString('da-DK');

  // positive/neutral only
  const lastPossible = state.momentum.last_possible_age;
  let text = '—';
  if(lastPossible != null){
    const diff = Math.max(0, lastPossible - res.possible_pension_age); // improvement only
    text = diff > 0.01 ? `+ ${fmtDeltaYearsToText(diff)}` : 'Uændret';
  }
  $('#deltaSince').textContent = text;

  // Save new momentum snapshot
  state.momentum.last_seen_at = now.toISOString();
  state.momentum.last_possible_age = res.possible_pension_age;
  localStorage.setItem('po_momentum', JSON.stringify(state.momentum));
}

function microGainsCatalog(age){
  // Age-dependent ordering only (not calc changes)
  const young = age < 32;

  const items = [
    { id:'stream', title:'Hvis 129 kr./md går til opsparing', meta:'Fx streaming/abonnement', deltaMonthly: 129 },
    { id:'coffee', title:'Hvis 300 kr./md går til opsparing', meta:'Små vaner', deltaMonthly: 300 },
    { id:'raise', title:'Hvis 1.000 kr./md fra lønforhøjelse går til opsparing', meta:'Strukturel', deltaMonthly: 1000 },
    { id:'car', title:'Hvis 1.200 kr./md frigøres til opsparing', meta:'Fx bilvalg ved næste skifte', deltaMonthly: 1200 },
    { id:'housing', title:'Hvis 2.000 kr./md frigøres til opsparing', meta:'Fx boligvalg/struktur', deltaMonthly: 2000 },
  ];

  const orderYoung = ['stream','coffee','raise','car','housing'];
  const orderOlder = ['raise','car','housing','stream','coffee'];
  const order = young ? orderYoung : orderOlder;

  return order.map(id => items.find(x => x.id === id));
}

function renderMicro(){
  const list = $('#microList');
  list.innerHTML = '';

  const age = state.profile.age ?? 35;
  const baseExtra = state.scenario.extra_saving_monthly;

  const items = microGainsCatalog(age).slice(0, 5); // show 5 in demo

  items.forEach(item => {
    // simulate selecting this micro gain (non-persistent baseline; but we show effect)
    const original = state.scenario.extra_saving_monthly;
    state.scenario.extra_saving_monthly = baseExtra + item.deltaMonthly;
    const res = computeResult();
    const gain = res.display_delta;
    state.scenario.extra_saving_monthly = original;

    const el = document.createElement('div');
    el.className = 'microItem';
    el.innerHTML = `
      <div>
        <div class="microTitle">${item.title}</div>
        <div class="microMeta">${item.meta}</div>
      </div>
      <button class="pill good" data-micro="${item.id}">+ ${gain}</button>
    `;
    list.appendChild(el);
  });

  // click handlers
  list.querySelectorAll('[data-micro]').forEach(btn => {
    btn.addEventListener('click', () => {
      const id = btn.getAttribute('data-micro');
      const item = items.find(x => x.id === id);
      if(!item) return;

      state.scenario.micro_gain_id = id;
      // apply as simulation: temporarily add to extra saving and keep it for demo flow
      state.scenario.extra_saving_monthly = baseExtra + item.deltaMonthly;
      $('#extraSaving').value = clamp(state.scenario.extra_saving_monthly, 0, 5000);
      $('#extraSavingManual').value = state.scenario.extra_saving_monthly;
      $('#extraSavingLabel').textContent = fmtInt(state.scenario.extra_saving_monthly);

      renderHero();
      renderAdjustPreview();
      screen('momentum');
      updateMomentum();
    });
  });
}

function buildLeadPayload(){
  const res = computeResult();
  const payload = {
    contact: {
      first_name: ($('#firstName').value || '').trim(),
      last_name: ($('#lastName').value || '').trim(),
      email: ($('#email').value || '').trim(),
      phone: ($('#phone').value || '').trim(),
      contact_preference: $('#pref').value
    },
    intent: $('#intent').value,
    profile: { age: state.profile.age },
    assumptions: {
      normal_pension_age: state.assumptions.normal_pension_age,
      return_rate: state.assumptions.return_rate,
      payout_target_monthly: state.assumptions.payout_target_monthly
    },
    scenario_state: {
      extra_saving_monthly: state.scenario.extra_saving_monthly,
      micro_gain_id: state.scenario.micro_gain_id
    },
    result: {
      possible_pension_age: res.possible_pension_age,
      normal_pension_age: res.normal_pension_age,
      delta_time: res.display_delta
    },
    timestamp: new Date().toISOString()
  };
  return payload;
}

function renderAdmin(){
  const list = $('#leadList');
  const leads = getLeads().slice().reverse();
  if(leads.length === 0){
    list.innerHTML = `<div class="leadCard"><div class="muted">Ingen leads endnu.</div></div>`;
    return;
  }
  list.innerHTML = '';
  leads.forEach((p) => {
    const d = new Date(p.timestamp);
    const el = document.createElement('div');
    el.className = 'leadCard';
    el.innerHTML = `
      <div class="leadHead">
        <div class="leadName">${(p.contact.first_name||'—')} ${(p.contact.last_name||'')}</div>
        <div class="leadTime">${d.toLocaleString('da-DK')}</div>
      </div>
      <div class="leadBody">
        <div><strong>Intent:</strong> ${p.intent}</div>
        <div><strong>Alder:</strong> ${p.profile.age}</div>
        <div><strong>Mulig:</strong> ${fmtAge(p.result.possible_pension_age)} · <strong>Normal:</strong> ${fmtAge(p.result.normal_pension_age)} · <strong>Gevinst:</strong> ${p.result.delta_time}</div>
        <div><strong>Ekstra opsparing:</strong> ${fmtInt(p.scenario_state.extra_saving_monthly)} kr./md</div>
        <div><strong>Udbetaling:</strong> ${fmtInt(p.assumptions.payout_target_monthly)} kr./md · <strong>Afkast:</strong> ${(p.assumptions.return_rate*100).toFixed(0)}%</div>
      </div>
      <details style="margin-top:10px">
        <summary class="muted" style="cursor:pointer">Se payload</summary>
        <pre class="payload" style="margin-top:10px">${JSON.stringify(p, null, 2)}</pre>
      </details>
    `;
    list.appendChild(el);
  });
}

// ---------- Wiring ----------
function init(){
  // load momentum
  try {
    const m = JSON.parse(localStorage.getItem('po_momentum') || 'null');
    if(m) state.momentum = m;
  } catch {}

  $('#buildStamp').textContent = `Build: ${new Date().toLocaleDateString('da-DK')}`;

  // demo fill
  $('#btnDemoFill').addEventListener('click', () => {
    $('#age').value = 38;
  });

  // show result
  $('#btnShowResult').addEventListener('click', () => {
    const age = parseInt($('#age').value, 10);
    if(!Number.isFinite(age) || age < 18 || age > 70) return alert('Indtast en alder mellem 18 og 70.');
    state.profile.age = age;

    // reset scenario
    state.scenario.extra_saving_monthly = 0;
    state.scenario.micro_gain_id = null;
    $('#extraSaving').value = 0;
    $('#extraSavingManual').value = '';
    $('#extraSavingLabel').textContent = '0';

    renderHero();
    screen('hero');
  });

  // admin toggle
  $('#btnAdmin').addEventListener('click', () => { screen('admin'); renderAdmin(); });
  $('#btnGoAdmin').addEventListener('click', () => { screen('admin'); renderAdmin(); });

  // hero -> adjust
  $('#btnAdjust').addEventListener('click', () => {
    screen('adjust');
    $('#extraSavingLabel').textContent = fmtInt(state.scenario.extra_saving_monthly);
    renderAdjustPreview();
  });

  // hero -> assumptions
  $('#btnAssumptions').addEventListener('click', () => {
    // set UI values
    const payout = state.assumptions.payout_target_monthly;
    const known = ['18000','20000','22000','25000'];
    if(known.includes(String(payout))){
      $('#payout').value = String(payout);
      $('#payoutCustomWrap').classList.add('hidden');
    } else {
      $('#payout').value = 'custom';
      $('#payoutCustomWrap').classList.remove('hidden');
      $('#payoutCustom').value = payout;
    }
    $('#returnRate').value = String(state.assumptions.return_rate);
    screen('assumptions');
  });

  // savings slider
  $('#extraSaving').addEventListener('input', (e) => {
    state.scenario.extra_saving_monthly = parseInt(e.target.value, 10) || 0;
    $('#extraSavingLabel').textContent = fmtInt(state.scenario.extra_saving_monthly);
    $('#extraSavingManual').value = state.scenario.extra_saving_monthly;
    renderAdjustPreview();
    renderHero();
  });

  // manual savings
  $('#extraSavingManual').addEventListener('input', (e) => {
    const v = Math.max(0, parseInt(e.target.value, 10) || 0);
    state.scenario.extra_saving_monthly = v;
    $('#extraSavingLabel').textContent = fmtInt(v);
    // slider is soft range; clamp for slider only
    $('#extraSaving').value = clamp(v, 0, 5000);
    renderAdjustPreview();
    renderHero();
  });

  // adjust navigation
  $('#btnBackToHero1').addEventListener('click', () => { screen('hero'); renderHero(); });
  $('#btnBackToHero2').addEventListener('click', () => { screen('hero'); renderHero(); });
  $('#btnMicroGains').addEventListener('click', () => { screen('micro'); renderMicro(); });
  $('#btnBackToAdjust').addEventListener('click', () => { screen('adjust'); renderAdjustPreview(); });

  // assumptions dropdown custom
  $('#payout').addEventListener('change', () => {
    const v = $('#payout').value;
    if(v === 'custom') $('#payoutCustomWrap').classList.remove('hidden');
    else $('#payoutCustomWrap').classList.add('hidden');
  });

  $('#btnApplyAssumptions').addEventListener('click', () => {
    // payout
    const v = $('#payout').value;
    let payout = 20000;
    if(v === 'custom'){
      payout = parseInt($('#payoutCustom').value, 10);
      if(!Number.isFinite(payout) || payout < 5000) return alert('Indtast en realistisk referenceudbetaling (min. 5.000).');
    } else {
      payout = parseInt(v, 10);
    }
    state.assumptions.payout_target_monthly = payout;

    // return
    state.assumptions.return_rate = parseFloat($('#returnRate').value);

    renderHero();
    screen('hero');
  });

  $('#btnBackToHero3').addEventListener('click', () => { screen('hero'); renderHero(); });

  // momentum
  $('#btnMomentum').addEventListener('click', () => {
    screen('momentum');
    updateMomentum();
  });
  $('#btnBackToHero4').addEventListener('click', () => { screen('hero'); renderHero(); });

  // lead
  $('#btnLead').addEventListener('click', () => { screen('lead'); });
  $('#btnBackToMomentum').addEventListener('click', () => { screen('momentum'); });

  // preview
  $('#btnPreview').addEventListener('click', () => {
    const payload = buildLeadPayload();
    $('#payloadBox').textContent = JSON.stringify(payload, null, 2);
    screen('preview');
  });
  $('#btnBackToLead').addEventListener('click', () => { screen('lead'); });

  // submit lead
  $('#btnSubmitLead').addEventListener('click', () => {
    const payload = buildLeadPayload();
    const leads = getLeads();
    leads.push(payload);
    setLeads(leads);
    screen('thanks');
  });

  // restart
  $('#btnRestart').addEventListener('click', () => {
    $('#age').value = '';
    // keep momentum and leads
    screen('start');
  });

  // admin actions
  $('#btnClearLeads').addEventListener('click', () => {
    if(confirm('Slet alle leads i demo?')){
      setLeads([]);
      renderAdmin();
    }
  });
  $('#btnBackToStart').addEventListener('click', () => { screen('start'); });

  // start state
  screen('start');
}

init();
